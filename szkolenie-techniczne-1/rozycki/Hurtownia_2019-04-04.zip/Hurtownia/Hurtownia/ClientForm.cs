﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hurtownia.Data;

namespace Hurtownia
{
    public partial class ClientForm : Form
    {

        private Client data = new Client();
        public ClientForm()
        {
            InitializeComponent();
            clientBindingSource.DataSource = data;
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nazwa klienta: " + data.ClientName);
            sb.AppendLine("Adres: " + data.Address);
            sb.AppendLine("Rabat: " + data.Discount);
            sb.AppendLine("VIP: " + (data.Vip == true ? "TAK" : "Nie"));
            
            MessageBox.Show(sb.ToString());
        }
    }
}
