﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hurtownia.Data
{
    public class Client
    {
        string clientName = "";
        string address = "";
        int discount = 10;
        bool vip = false;
        public string ClientName
        {
            get { return clientName; }
            set { clientName = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public int Discount
        {
            get { return discount; }
            set { discount = value; }
        }
        public bool Vip
        {
            get { return vip; }
            set { vip = value; }
        }
    }
}
