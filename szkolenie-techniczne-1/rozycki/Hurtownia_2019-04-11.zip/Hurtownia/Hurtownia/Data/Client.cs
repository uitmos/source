﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Hurtownia.Data
{
    [XmlRoot("klient")]
    public class Client
    {
        string clientName = "";
        string address = "";
        int discount = 10;
        bool vip = false;

        [XmlElement("nazwa-kontrahenta")]
        public string ClientName
        {
            get { return clientName; }
            set { clientName = value; }
        }
        [XmlElement("adres")]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        [XmlElement("rabat")]
        public int Discount
        {
            get { return discount; }
            set { discount = value; }
        }
        [XmlAttribute("VIP")]
        public bool Vip
        {
            get { return vip; }
            set { vip = value; }
        }
    }
}
