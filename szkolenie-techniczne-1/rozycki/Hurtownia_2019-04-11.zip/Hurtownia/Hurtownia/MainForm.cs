﻿using Hurtownia.Data;
using Hurtownia.Serializers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurtownia
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dodajKontrahentaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClientForm clientForm = new ClientForm();
            clientForm.MdiParent = this;
            clientForm.Show();
        }

        private void dodajProduktToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm();
            productForm.MdiParent = this;
            productForm.Show();
        }

        private void importToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Import danych kontrahenta";
                openFileDialog.Filter = "Pliki formatu Xml (*.xml)|*.xml|Wszystkie pliki (*.*)|*.*";
                openFileDialog.Multiselect = false;
                if (openFileDialog.ShowDialog() == DialogResult.OK) {
                    Client data = ClientXmlSerializer.Deserialize(openFileDialog.FileName);
                    ClientForm clintForm = new ClientForm(data);
                    clintForm.MdiParent = this;
                    clintForm.Show();
                }
            } catch (Exception x) {
                MessageBox.Show("Podczas importu wystąpił błąd: " + x.Message);
            }
        }

        private void importujDaneProduktuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Import danych produktu";
                openFileDialog.Filter = "Pliki formatu Xml (*.xml)|*.xml|Wszystkie pliki (*.*)|*.*";
                openFileDialog.Multiselect = false;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Product data = ProductXmlSerializer.Deserialize(openFileDialog.FileName);
                    ProductForm clintForm = new ProductForm(data);
                    clintForm.MdiParent = this;
                    clintForm.Show();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Podczas importu wystąpił błąd: " + x.Message);
            }
        }

        private void uszeregujKaskadowoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void uszeregujWPionieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void uszeregujWPoziomieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }
    }
}
