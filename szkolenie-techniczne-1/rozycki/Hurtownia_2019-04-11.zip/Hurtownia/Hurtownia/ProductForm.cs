﻿using Hurtownia.Serializers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurtownia
{
    public partial class ProductForm : Form
    {
        private Product data = new Product();
        public ProductForm()
        {
            InitializeComponent();
            productBindingSource.DataSource = data;
        }

        public ProductForm(Product importedData)
        {
            data = importedData;
            InitializeComponent();
            productBindingSource.DataSource = data;
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            /*StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nazwa produktu: " + data.ProductName);
            sb.AppendLine("Grupa: " + data.Group);
            sb.AppendLine("Data ważności: " + data.ValidDate.ToShortDateString());
            sb.AppendLine("Numer seryjny: " + data.LotNumber.ToString());
            sb.AppendLine("Stan na magazynie: " + data.StockAmount);
            sb.AppendLine("Opakowanie: " + data.Package);
            sb.AppendLine("Bestseller: " + (data.IsBestseller == true ? "TAK" : "Nie"));
            sb.AppendLine("Opis produktu: " + data.Description);
            MessageBox.Show(sb.ToString());*/

            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Title = "Eksport danych porduktu";
                saveFileDialog.Filter = "Pliki formatu Xml (*.xml)|*.xml|Wszystkie pliki (*.*)|*.*";
                if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    ProductXmlSerializer.Serialize(data, saveFileDialog.FileName);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Podczas eksportu wystąpił błąd: " + x.Message);
            }

        }
    }
}
