﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hurtownia.Data;
using Hurtownia.Serializers;
using Hurtownia.DataAccess;

namespace Hurtownia
{
    public partial class ClientForm : Form
    {

        private Client data = new Client();
        public ClientForm()
        {
            InitializeComponent();
            clientBindingSource.DataSource = data;
        }

        public ClientForm(Client importedData)
        {
            data = importedData;
            InitializeComponent();
            clientBindingSource.DataSource = data;
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            /*StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nazwa klienta: " + data.ClientName);
            sb.AppendLine("Adres: " + data.Address);
            sb.AppendLine("Rabat: " + data.Discount);
            sb.AppendLine("VIP: " + (data.Vip == true ? "TAK" : "Nie"));
            
            MessageBox.Show(sb.ToString());
            */

            try {
                if (DataContext.AddOrEditClient(data) == true)
                {
                    this.Close();
                }
            } catch (Exception x) {
                MessageBox.Show("Podczas zapisu wystąpił błąd: " + x.Message);
            }


        }

        private void btSaveToXML_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Title = "Eksport danych kontrahenta";
                saveFileDialog.Filter = "Pliki formatu Xml (*.xml)|*.xml|Wszystkie pliki (*.*)|*.*";
                if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    ClientXmlSerializer.Serialize(data, saveFileDialog.FileName);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Podczas eksportu wystąpił błąd: " + x.Message);
            }
        }
    }
}
