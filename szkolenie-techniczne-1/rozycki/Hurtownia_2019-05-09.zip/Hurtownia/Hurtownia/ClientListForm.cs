﻿using Hurtownia.Data;
using Hurtownia.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurtownia
{
    public partial class ClientListForm : Form
    {
        public ClientListForm()
        {
            InitializeComponent();
            this.clientBindingSource.DataSource = DataContext.GetClientList();
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            ClientForm clientForm = new ClientForm();
            clientForm.MdiParent = this.ParentForm;
            clientForm.Show();
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dataGridView1.SelectedRows){
                Client client = row.DataBoundItem as Client;
                if (client != null) {
                    ClientForm clientForm = new ClientForm(client); 
                    clientForm.MdiParent = this.ParentForm;
                    clientForm.Show();
                }
            }
        }

        private void btRefresh_Click(object sender, EventArgs e)
        {
            this.clientBindingSource.ResetBindings(true);
        }
    }
}
