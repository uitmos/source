﻿using Hurtownia.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurtownia.DataAccess
{
    class DataContext
    {
        static List<Product> products = new List<Product>();
        static List<Client> clients = new List<Client>();
        
        public static List<Client> GetClientList() { return clients; }
        public static List<Product> GetProductList() { return products; }


        public static bool AddOrEditClient(Client value) {
            if (value.ClientId == 0){
                value.ClientId = clients.Count > 0 ? clients.Max(x => x.ClientId) + 1 : 1;
                clients.Add(value);
            } else {
                Client client = clients.FirstOrDefault(x => x.ClientId == value.ClientId);
                if (client != null) {
                    client.ClientName = value.ClientName;
                    client.Address = value.Address;
                    client.Discount = value.Discount;
                    client.Vip = value.Vip;
                }
            }

            MessageBox.Show("Liczba kontrahentów: "+clients.Count);
            return true;
        }
        public static bool AddOrEditProduct(Product value) {
            if (value.ProductId == 0) {
                value.ProductId = products.Count > 0 ? products.Max(x => x.ProductId) + 1 : 1;
                products.Add(value);
            } else {
                Product product = products.FirstOrDefault(x => x.ProductId == value.ProductId);
                if (product != null) {
                    product.ProductName = value.ProductName;
                    product.Group = value.Group;
                    product.ValidDate = value.ValidDate;
                    product.LotNumber = value.LotNumber;
                    product.StockAmount = value.StockAmount;
                    product.Package = value.Package;
                    product.IsBestseller = value.IsBestseller;
                    product.Description = value.Description;
                }
            }
            MessageBox.Show("Liczba producktów: " + products.Count);
            return true;
        }
    }
}
