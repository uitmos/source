﻿namespace Hurtownia
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eksportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importujDaneProduktuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zamknijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajKontrahentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajProduktToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.daneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formularzeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.widokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uszeregujWPoziomieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uszeregujWPionieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uszeregujKaskadowoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.listaProduktówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaKontrahentówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem,
            this.operacjeToolStripMenuItem,
            this.daneToolStripMenuItem,
            this.formularzeToolStripMenuItem,
            this.widokToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.formularzeToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(626, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem,
            this.eksportToolStripMenuItem,
            this.importujDaneProduktuToolStripMenuItem,
            this.zamknijToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.plikToolStripMenuItem.Text = "Plik";
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.importToolStripMenuItem.Text = "Importuj dane kontrahenta";
            this.importToolStripMenuItem.Click += new System.EventHandler(this.importToolStripMenuItem_Click);
            // 
            // eksportToolStripMenuItem
            // 
            this.eksportToolStripMenuItem.Name = "eksportToolStripMenuItem";
            this.eksportToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.eksportToolStripMenuItem.Text = "Eksport";
            // 
            // importujDaneProduktuToolStripMenuItem
            // 
            this.importujDaneProduktuToolStripMenuItem.Name = "importujDaneProduktuToolStripMenuItem";
            this.importujDaneProduktuToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.importujDaneProduktuToolStripMenuItem.Text = "Importuj dane produktu";
            this.importujDaneProduktuToolStripMenuItem.Click += new System.EventHandler(this.importujDaneProduktuToolStripMenuItem_Click);
            // 
            // zamknijToolStripMenuItem
            // 
            this.zamknijToolStripMenuItem.Name = "zamknijToolStripMenuItem";
            this.zamknijToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.zamknijToolStripMenuItem.Text = "Zamknij";
            this.zamknijToolStripMenuItem.Click += new System.EventHandler(this.zamknijToolStripMenuItem_Click);
            // 
            // operacjeToolStripMenuItem
            // 
            this.operacjeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajKontrahentaToolStripMenuItem,
            this.dodajProduktToolStripMenuItem});
            this.operacjeToolStripMenuItem.Name = "operacjeToolStripMenuItem";
            this.operacjeToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.operacjeToolStripMenuItem.Text = "Operacje";
            // 
            // dodajKontrahentaToolStripMenuItem
            // 
            this.dodajKontrahentaToolStripMenuItem.Name = "dodajKontrahentaToolStripMenuItem";
            this.dodajKontrahentaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.dodajKontrahentaToolStripMenuItem.Text = "Dodaj kontrahenta";
            this.dodajKontrahentaToolStripMenuItem.Click += new System.EventHandler(this.dodajKontrahentaToolStripMenuItem_Click);
            // 
            // dodajProduktToolStripMenuItem
            // 
            this.dodajProduktToolStripMenuItem.Name = "dodajProduktToolStripMenuItem";
            this.dodajProduktToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.dodajProduktToolStripMenuItem.Text = "Dodaj produkt";
            this.dodajProduktToolStripMenuItem.Click += new System.EventHandler(this.dodajProduktToolStripMenuItem_Click);
            // 
            // daneToolStripMenuItem
            // 
            this.daneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listaProduktówToolStripMenuItem,
            this.listaKontrahentówToolStripMenuItem});
            this.daneToolStripMenuItem.Name = "daneToolStripMenuItem";
            this.daneToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.daneToolStripMenuItem.Text = "Dane";
            // 
            // formularzeToolStripMenuItem
            // 
            this.formularzeToolStripMenuItem.Name = "formularzeToolStripMenuItem";
            this.formularzeToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.formularzeToolStripMenuItem.Text = "Formularze";
            // 
            // widokToolStripMenuItem
            // 
            this.widokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uszeregujWPoziomieToolStripMenuItem,
            this.uszeregujWPionieToolStripMenuItem,
            this.uszeregujKaskadowoToolStripMenuItem});
            this.widokToolStripMenuItem.Name = "widokToolStripMenuItem";
            this.widokToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.widokToolStripMenuItem.Text = "Widok";
            // 
            // uszeregujWPoziomieToolStripMenuItem
            // 
            this.uszeregujWPoziomieToolStripMenuItem.Name = "uszeregujWPoziomieToolStripMenuItem";
            this.uszeregujWPoziomieToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.uszeregujWPoziomieToolStripMenuItem.Text = "Uszereguj w poziomie";
            this.uszeregujWPoziomieToolStripMenuItem.Click += new System.EventHandler(this.uszeregujWPoziomieToolStripMenuItem_Click);
            // 
            // uszeregujWPionieToolStripMenuItem
            // 
            this.uszeregujWPionieToolStripMenuItem.Name = "uszeregujWPionieToolStripMenuItem";
            this.uszeregujWPionieToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.uszeregujWPionieToolStripMenuItem.Text = "Uszereguj w pionie";
            this.uszeregujWPionieToolStripMenuItem.Click += new System.EventHandler(this.uszeregujWPionieToolStripMenuItem_Click);
            // 
            // uszeregujKaskadowoToolStripMenuItem
            // 
            this.uszeregujKaskadowoToolStripMenuItem.Name = "uszeregujKaskadowoToolStripMenuItem";
            this.uszeregujKaskadowoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.uszeregujKaskadowoToolStripMenuItem.Text = "Uszereguj kaskadowo";
            this.uszeregujKaskadowoToolStripMenuItem.Click += new System.EventHandler(this.uszeregujKaskadowoToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(626, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton1.Text = "Dodaj kontrahenta";
            this.toolStripButton1.Click += new System.EventHandler(this.dodajKontrahentaToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(103, 22);
            this.toolStripButton2.Text = "Dodaj produkt";
            this.toolStripButton2.Click += new System.EventHandler(this.dodajProduktToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 412);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(626, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(190, 17);
            this.toolStripStatusLabel1.Text = "Program do zarządzania hurtownią";
            // 
            // listaProduktówToolStripMenuItem
            // 
            this.listaProduktówToolStripMenuItem.Name = "listaProduktówToolStripMenuItem";
            this.listaProduktówToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.listaProduktówToolStripMenuItem.Text = "Lista produktów";
            this.listaProduktówToolStripMenuItem.Click += new System.EventHandler(this.listaProduktówToolStripMenuItem_Click);
            // 
            // listaKontrahentówToolStripMenuItem
            // 
            this.listaKontrahentówToolStripMenuItem.Name = "listaKontrahentówToolStripMenuItem";
            this.listaKontrahentówToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.listaKontrahentówToolStripMenuItem.Text = "Lista kontrahentów";
            this.listaKontrahentówToolStripMenuItem.Click += new System.EventHandler(this.listaKontrahentówToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 434);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Hurtownia";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eksportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zamknijToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacjeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem daneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formularzeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem widokToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem dodajKontrahentaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodajProduktToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem importujDaneProduktuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uszeregujWPoziomieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uszeregujWPionieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uszeregujKaskadowoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaProduktówToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaKontrahentówToolStripMenuItem;
    }
}