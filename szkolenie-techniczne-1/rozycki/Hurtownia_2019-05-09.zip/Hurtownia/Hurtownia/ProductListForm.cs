﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurtownia
{
    public partial class ProductListForm : Form
    {
        public ProductListForm()
        {
            InitializeComponent();
            this.productBindingSource.DataSource = DataAccess.DataContext.GetProductList();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm();
            productForm.MdiParent = this.ParentForm;
            productForm.Show();
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dataGridView1.SelectedRows)
            {
                Product product = row.DataBoundItem as Product;
                if (product != null)
                {
                    ProductForm productForm = new ProductForm(product);
                    productForm.MdiParent = this.ParentForm;
                    productForm.Show();
                }
            }
        }

        private void btRefresh_Click(object sender, EventArgs e)
        {
            this.productBindingSource.ResetBindings(true);
        }
    }
}
