﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Hurtownia.Serializers
{
    class ProductXmlSerializer
    {

        public static void Serialize(Product product, string filePath) {
            XmlSerializer serializer = new XmlSerializer(typeof(Product));
            TextWriter textWriter = new StreamWriter(filePath);
            serializer.Serialize(textWriter, product);
            textWriter.Close();
        }
        public static Product Deserialize(string filePath) {
            XmlSerializer deserializer = new XmlSerializer(typeof(Product));
            TextReader textReader = new StreamReader(filePath);
            Product product = (Product)deserializer.Deserialize(textReader);
            textReader.Close(); return product; }
    }
}
